# Estética Bella Studio

Panel administrativo web de una estética, desarrollado con PHP, MySQL, HTML, CSS y JavaScript. Incluye clientes, servicios, personal, citas, cobros, inventario, gastos, reportes, usuarios y configuración.

## Instalación en AppServ

1. Copiar la carpeta `bella-studio` dentro de `C:\AppServ\www`.
2. Iniciar los servicios Apache y MySQL.
3. Abrir `http://localhost/bella-studio/`.
4. Completar la conexión con los datos locales de MySQL y crear la primera cuenta administradora. No hay contraseña predefinida.

El instalador crea las tablas y cuatro servicios de ejemplo. La base debe ser nueva y vacía. `config.php` se genera en el equipo y se excluye del repositorio.

En XAMPP, usar `C:\xampp\htdocs` en lugar de `C:\AppServ\www`.

## Requisitos

- Apache 2.4 con soporte de `.htaccess`.
- PHP 7.3+ con PDO MySQL, mbstring y sesiones.
- MySQL 5.7+ o MariaDB 10.4+, InnoDB y utf8mb4.
- Permisos de escritura durante la instalación y en `storage` para registros privados.

## Modelo de datos

El esquema está en `bella-studio/database/schema.sql`. Contiene diez tablas y ocho relaciones. La carpeta `modelo` incluye el diagrama y el diccionario de datos. El respaldo académico con datos se entrega por separado para evitar publicar información operativa.

## Funcionamiento

- Administración gestiona todos los módulos; recepción gestiona clientes, agenda y cobros y consulta catálogos.
- El cliente de una cita se escribe en el formulario; si es nuevo se registra al guardar. Sus datos se completan en Clientes.
- Se impiden reservas superpuestas por profesional y cobros duplicados por cita.
- Los catálogos permiten archivo y reactivación para conservar el historial.
- Las entradas y salidas de inventario guardan motivo y responsable; no se permite stock negativo.
- El reporte usa los cobros y gastos del periodo; permite exportar cobros CSV e imprimir.

## Alcance

La aplicación funciona de manera independiente en localhost. Todavía no hay app móvil ni API de integración. No procesa tarjetas, no genera CFDI y no contempla anticipos ni pagos parciales. El stock de insumos se registra manualmente.

El manual formal y las evidencias forman parte del paquete de entrega de la Actividad 3 de Metodología No Code. El README de la aplicación incluye detalles de instalación, respaldo y resolución de problemas.

## Equipo

- Bartolo Vaquero Ximena: coordinación y documentación.
- Chávez Beltrán Noe: lógica y módulos.
- Gómez Angeles Evelin: base de datos e instalación.
- Hernández Rafael Adán: diseño y pruebas.

Universidad Tecnológica del Valle de Mezquital. Entrega: 19 de noviembre de 2026.

## Información privada

No subir `config.php`, registros de `storage`, contraseñas MySQL ni respaldos de datos personales. El archivo `.gitignore` excluye los archivos privados de la instalación.
