# Validación realizada

Fecha: 18 de noviembre de 2026.

## Entorno y resultado

- Windows, PHP **7.3.10** con PDO MySQL y mbstring.
- MySQL Community Server **8.0.17**, InnoDB y utf8mb4, en una instancia aislada de pruebas.
- Aplicación servida mediante el servidor local integrado de PHP.
- **65 comprobaciones HTTP aprobadas**, con base de datos real y cuentas/datos ficticios.
- Revisión de sintaxis satisfactoria en los ocho archivos PHP.
- Inspección visual de panel, agenda y gastos en navegador; se revisaron las distribuciones estrecha y de escritorio.

## Recorridos comprobados

- Instalación desde cero, creación de base y cuenta administradora, redirección al acceso y bloqueo posterior del instalador.
- Acceso válido e inválido, cierre de sesión, cambio de contraseña y entrada con la nueva contraseña.
- Rechazo de solicitudes sin protección de formulario válida y salida HTML escapada para nombres con etiquetas.
- Creación y edición de clientes, profesionales y servicios.
- Reserva, edición y cancelación de citas; rechazo de superposición horaria por profesional.
- Conservación del precio y duración de la reserva al cambiar el catálogo.
- Cobro real en la base, creación de folio, rechazo del doble cobro, rechazo de cobros de citas canceladas y bloqueo de edición de citas cobradas.
- Creación de productos, entradas y salidas, auditoría de movimientos, rechazo de SKU duplicado y de stock negativo.
- Registro de gastos, rechazo de importes negativos y fechas inexistentes.
- Reporte con ingreso de $350, gasto de $50 y balance de $300; exportación CSV y rechazo de rangos inválidos.
- Configuración del negocio, alta de recepción, permisos, desactivación de cuentas e invalidación de acceso de una sesión desactivada.
- Archivo de clientes conservando cobros, consulta de archivados, reactivación y edición posterior.
- Respuesta 404 para páginas inexistentes y carga correcta de las doce pantallas administrativas.
- Ocho intentos inválidos desde sesiones diferentes y bloqueo del siguiente intento, incluso usando las credenciales correctas.

## Alcance

Los ejecutables de PHP 7.3.10 y MySQL 8.0.17 usados son los disponibles en AppServ en este equipo; también se confirmó que existe `C:\AppServ\www`. Las pruebas se ejecutaron en una copia y una instancia MySQL aisladas: no se instaló el proyecto en esa carpeta ni se usaron las credenciales o bases reales del usuario. No se ejecutó una prueba directa mediante el servicio Apache de AppServ ni con MariaDB o XAMPP. El paquete incluye las instrucciones para AppServ y la alternativa para XAMPP. Las versiones PHP 8.x y MariaDB indicadas en el manual son objetivos de compatibilidad, no entornos ejecutados en esta revisión.

El MySQL 8 de prueba requirió un usuario de autenticación compatible con el PHP 7.3 disponible. El ajuste se aplicó únicamente a la instancia aislada. No se usó ni modificó una base del usuario.

No se realizaron auditoría de seguridad externa, pruebas de carga ni pruebas concurrentes con varios servidores PHP. Las transacciones, bloqueos de filas e índice único de pagos implementan las reglas contra superposición y duplicación; las pruebas HTTP verificaron sus recorridos secuenciales.

El paquete se entrega sin `config.php`, datos de prueba ni contraseñas predefinidas. Los datos usados para la validación se mantuvieron en una copia separada.
