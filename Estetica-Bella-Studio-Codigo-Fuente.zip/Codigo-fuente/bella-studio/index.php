<?php
require __DIR__.'/app/bootstrap.php';
if (!is_file(__DIR__.'/config.php')) go('install.php');
try {
    db();
    if (!empty($_SESSION['user'])) {
        $u=one('SELECT id,name,role FROM users WHERE id=? AND active=1',[$_SESSION['user']['id']]);
        if (!$u || time()-($_SESSION['last_activity'] ?? 0)>7200) unset($_SESSION['user']);
        else { $_SESSION['user']=$u; $_SESSION['last_activity']=time(); }
    }
    if (empty($_SESSION['user'])) { require __DIR__.'/app/login.php'; exit; }
    $entities=require __DIR__.'/app/entities.php';
    $nav=['dashboard'=>['Resumen','◫'],'appointments'=>['Agenda','▦'],'clients'=>['Clientes','♡'],'services'=>['Servicios','✧'],'staff'=>['Personal','♧'],'payments'=>['Cobros','◎'],'products'=>['Inventario','◇'],'expenses'=>['Gastos','↗'],'reports'=>['Reportes','▥'],'users'=>['Usuarios','♙'],'settings'=>['Mi estudio','⚙'],'account'=>['Mi cuenta','◉']];
    $isAdmin=$_SESSION['user']['role']==='admin';
    $page=(string)($_GET['page'] ?? 'dashboard');
    if (!isset($nav[$page])) { http_response_code(404); $page='notfound'; }
    if (!$isAdmin && in_array($page,['expenses','reports','users','settings'],true)) { http_response_code(403); $page='forbidden'; }
    if ($_SERVER['REQUEST_METHOD']==='POST') require __DIR__.'/app/actions.php';
    if ($page==='reports' && isset($_GET['export'])) {
        require_admin(); list($from,$to,$until)=report_range();
        $data=rows('SELECT p.id,p.paid_at,c.name client,s.name service,p.method,p.amount FROM payments p JOIN appointments a ON a.id=p.appointment_id JOIN clients c ON c.id=a.client_id JOIN services s ON s.id=a.service_id WHERE p.paid_at>=? AND p.paid_at<? ORDER BY p.paid_at',[$from,$until]);
        header('Content-Type: text/csv; charset=UTF-8'); header('Content-Disposition: attachment; filename="bella-cobros-'.$from.'-'.$to.'.csv"');
        $out=fopen('php://output','w'); fwrite($out,"\xEF\xBB\xBF"); fputcsv($out,['Folio','Fecha','Cliente','Servicio','Método','Importe MXN']);
        foreach ($data as $r) { foreach ($r as &$v) if (preg_match('/^[=+@\-\t\r\n]/u',(string)$v)) $v="'".$v; unset($v); fputcsv($out,$r); } fclose($out); exit;
    }
    $business=setting('business_name','Estética Bella Studio');
} catch (Throwable $ex) {
    error_log((string)$ex);
    if ($ex instanceof RuntimeException && !($ex instanceof PDOException)) { http_response_code(400); exit(e($ex->getMessage()).' Vuelve a la página anterior y revisa los filtros.'); }
    http_response_code(503); exit('No se pudo abrir el estudio. Inicia MySQL y revisa config.php. Consulta storage/php-errors.log para el diagnóstico.');
}
$oldInput=$_SESSION['old_input'] ?? []; unset($_SESSION['old_input']);
function field_value(string $name, $default='') { global $oldInput; return $oldInput[$name] ?? $default; }
?><!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($nav[$page][0] ?? 'Aviso')?> · <?=e($business)?></title><link rel="stylesheet" href="assets/style.css"><script src="assets/app.js" defer></script></head><body>
<aside class="sidebar" id="sidebar"><a href="index.php" class="brand"><span class="brand-mark small">B<span>✧</span></span><span>Bella Studio<small>ESTÉTICA & BIENESTAR</small></span></a><div class="nav-label">TU ESPACIO DE TRABAJO</div><nav aria-label="Navegación principal"><?php foreach ($nav as $key=>$n): if (!$isAdmin && in_array($key,['expenses','reports','users','settings'],true)) continue; ?><a href="index.php?page=<?=e($key)?>" class="nav-item <?=$key===$page?'selected':''?>" <?=$key===$page?'aria-current="page"':''?>><span aria-hidden="true"><?=e($n[1])?></span><?=e($n[0])?></a><?php endforeach ?></nav><div class="sidebar-bottom"><span class="live-dot"></span> Tu estudio, en armonía<small>Hecho para cuidar cada detalle.</small></div></aside>
<div class="workspace"><header class="topbar"><button class="menu-button" type="button" aria-controls="sidebar" aria-expanded="false" aria-label="Abrir menú">☰</button><div class="breadcrumb"><?=e($business)?> <span>/</span> <b><?=e($nav[$page][0] ?? 'Aviso')?></b></div><div class="user-area"><span class="avatar"><?=e(mb_substr($_SESSION['user']['name'],0,1))?></span><div><?=e($_SESSION['user']['name'])?><small><?=$isAdmin?'Administración':'Recepción'?></small></div><form method="post"><?=csrf()?><input type="hidden" name="action" value="logout"><button class="text-button" title="Cerrar sesión">Salir</button></form></div></header>
<main class="main"><?php if (!empty($_SESSION['flash'])): ?><div class="notice <?=e($_SESSION['flash'][1])?>" role="status"><?=e($_SESSION['flash'][0])?></div><?php unset($_SESSION['flash']); endif ?>
<?php try { require __DIR__.'/app/views.php'; } catch (Throwable $ex) { error_log((string)$ex); echo '<div class="notice error" role="alert">'.e($ex instanceof PDOException?'No se pudo cargar esta sección. Revisa el registro de errores.':$ex->getMessage()).'</div>'; } ?>
<footer class="page-footer"><?=e($business)?> <span>Con amor por los pequeños detalles · <?=date('Y')?></span></footer></main></div></body></html>
