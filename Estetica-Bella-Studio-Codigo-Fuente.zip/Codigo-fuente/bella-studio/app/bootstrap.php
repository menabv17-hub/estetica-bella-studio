<?php
declare(strict_types=1);
date_default_timezone_set('America/Mexico_City');
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', dirname(__DIR__) . '/storage/php-errors.log');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: same-origin');
header("Content-Security-Policy: default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; form-action 'self'; frame-ancestors 'none'; base-uri 'self'");
header('Cache-Control: no-store');
session_name('bella_studio');
session_set_cookie_params(['httponly'=>true, 'secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'samesite'=>'Lax', 'path'=>'/']);
ini_set('session.use_strict_mode', '1');
session_start();
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
function e($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function csrf(): string { return '<input type="hidden" name="csrf" value="'.e($_SESSION['csrf']).'">'; }
function check_csrf(): void {
    if (!hash_equals($_SESSION['csrf'], (string)($_POST['csrf'] ?? ''))) { http_response_code(419); exit('La sesión del formulario venció. Regresa y actualiza la página.'); }
}
function go(string $url): void { header('Location: '.$url); exit; }
function flash(string $message, string $kind='success'): void { $_SESSION['flash'] = [$message,$kind]; }
function db(): PDO {
    static $pdo;
    if (!$pdo) {
        $c = require dirname(__DIR__).'/config.php';
        $pdo = new PDO('mysql:host='.$c['host'].';port='.$c['port'].';dbname='.$c['database'].';charset=utf8mb4', $c['username'],$c['password'], [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES=>false, PDO::ATTR_TIMEOUT=>5]);
    }
    return $pdo;
}
function rows(string $sql, array $params=[]): array { $s=db()->prepare($sql); $s->execute($params); return $s->fetchAll(); }
function one(string $sql, array $params=[]) { return rows($sql,$params)[0] ?? null; }
function run(string $sql, array $params=[]): void { $s=db()->prepare($sql); $s->execute($params); }
function setting(string $key, string $default=''): string { $s=one('SELECT value FROM settings WHERE name=?',[$key]); return $s ? $s['value'] : $default; }
function money($n): string { return '$'.number_format((float)$n,2).' MXN'; }
function now(): string { return date('Y-m-d H:i:s'); }
function require_admin(): void { if (($_SESSION['user']['role'] ?? '') !== 'admin') throw new RuntimeException('Esta operación requiere una cuenta administradora.'); }
function text_field(string $name, int $max=120, bool $required=true): string {
    $v=trim((string)($_POST[$name] ?? ''));
    if (($required && $v==='') || mb_strlen($v)>$max) throw new RuntimeException('Revisa el campo «'.$name.'» (máximo '.$max.' caracteres).');
    return $v;
}
function number_field(string $name, float $min=0, float $max=99999999.99): string {
    $v=(string)($_POST[$name] ?? '');
    if (!preg_match('/^\d+(\.\d{1,2})?$/D',$v) || (float)$v<$min || (float)$v>$max) throw new RuntimeException('Revisa el importe «'.$name.'».');
    return number_format((float)$v,2,'.','');
}
function int_field(string $name, int $min=0, int $max=1000000): int {
    $v=filter_var($_POST[$name] ?? null,FILTER_VALIDATE_INT);
    if ($v===false || $v===null || $v<$min || $v>$max) throw new RuntimeException('Revisa el número «'.$name.'».');
    return $v;
}
function date_value(string $v): string {
    $d=DateTime::createFromFormat('!Y-m-d',$v);
    if (!$d || $d->format('Y-m-d')!==$v || $v<'2000-01-01' || $v>'2100-12-31') throw new RuntimeException('La fecha debe estar entre 2000 y 2100.');
    return $v;
}
function email_field(): string {
    $v=text_field('email',190,false);
    if ($v!=='' && !filter_var($v,FILTER_VALIDATE_EMAIL)) throw new RuntimeException('El correo electrónico no es válido.');
    return mb_strtolower($v);
}
function active_record(string $table, int $id): array {
    $r=one("SELECT * FROM $table WHERE id=? AND active=1",[$id]);
    if (!$r) throw new RuntimeException('El registro seleccionado ya no está disponible.');
    return $r;
}
function report_range(): array {
    $from=date_value((string)($_GET['from'] ?? date('Y-m-01')));
    $to=date_value((string)($_GET['to'] ?? date('Y-m-d')));
    if ($from>$to) throw new RuntimeException('La fecha inicial debe ser anterior a la final.');
    return [$from,$to,date('Y-m-d',strtotime($to.' +1 day'))];
}
function appointment_rows(string $where='', array $params=[]): array {
    return rows('SELECT a.*, c.name client, s.name service, t.name professional FROM appointments a JOIN clients c ON c.id=a.client_id JOIN services s ON s.id=a.service_id JOIN staff t ON t.id=a.staff_id '.$where.' ORDER BY a.starts_at DESC LIMIT 500',$params);
}
