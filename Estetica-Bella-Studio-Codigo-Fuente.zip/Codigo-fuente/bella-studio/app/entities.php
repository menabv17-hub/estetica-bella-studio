<?php
// Lista cerrada: los nombres de tabla y campos nunca proceden de la solicitud.
return [
 'clients'=>['label'=>'Clientes','singular'=>'cliente','icon'=>'♡','fields'=>[
   'name'=>['Nombre completo','text'], 'phone'=>['Teléfono','tel'], 'email'=>['Correo electrónico','email',false], 'notes'=>['Preferencias y notas','textarea',false]]],
 'services'=>['label'=>'Servicios','singular'=>'servicio','icon'=>'✧','fields'=>[
   'name'=>['Nombre del servicio','text'],'category'=>['Categoría','text'],'price'=>['Precio · MXN','money'],'duration'=>['Duración · minutos','integer']]],
 'staff'=>['label'=>'Personal','singular'=>'profesional','icon'=>'♧','fields'=>[
   'name'=>['Nombre completo','text'],'specialty'=>['Especialidad','text'],'phone'=>['Teléfono','tel',false]]],
 'products'=>['label'=>'Inventario','singular'=>'producto','icon'=>'◇','fields'=>[
   'name'=>['Nombre del producto','text'],'sku'=>['Código / SKU','text'],'cost'=>['Costo unitario · MXN','money'],'minimum'=>['Stock mínimo','integer']]],
];
