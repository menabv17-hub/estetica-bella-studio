<?php
check_csrf();
$action=(string)($_POST['action'] ?? '');
$return='index.php?page='.urlencode($page);
try {
    if ($action==='logout') { $_SESSION=[]; session_regenerate_id(true); go('index.php'); }
    if (in_array($action,['save_entity','archive','restore'],true)) {
        if (!isset($entities[$page])) throw new RuntimeException('Módulo inválido.');
        if ($page!=='clients') require_admin();
        $id=int_field('id',0);
        if ($action==='restore') {
            run("UPDATE $page SET active=1 WHERE id=?",[$id]);
            flash('Registro reactivado.'); go($return);
        }
        if ($action==='archive') {
            if ($page!=='clients') require_admin();
            active_record($page,$id);
            run("UPDATE $page SET active=0 WHERE id=?",[$id]);
            flash('Registro archivado. El historial se conserva.'); go($return);
        }
        $values=[];
        foreach ($entities[$page]['fields'] as $key=>$f) {
            if ($f[1]==='money') $values[$key]=number_field($key);
            elseif ($f[1]==='integer') $values[$key]=int_field($key,$key==='duration'?5:0,$key==='duration'?720:1000000);
            elseif ($key==='email') $values[$key]=email_field();
            else $values[$key]=text_field($key,$key==='notes'?2000:($key==='phone'?30:($key==='sku'?60:($key==='category'?80:120))),$f[2] ?? true);
        }
        if ($id) {
            active_record($page,$id);
            $sets=implode(',',array_map(function($k){return "$k=?";},array_keys($values)));
            run("UPDATE $page SET $sets WHERE id=?",array_merge(array_values($values),[$id]));
        } else {
            $keys=implode(',',array_keys($values)); $marks=implode(',',array_fill(0,count($values),'?'));
            run("INSERT INTO $page ($keys) VALUES ($marks)",array_values($values));
        }
        flash('Registro guardado.'); go($return);
    }
    if ($action==='save_appointment') {
        $id=int_field('id',0); $service=int_field('service_id',1); $staff=int_field('staff_id',1);
        $clientName=text_field('client_name',120);
        $start=text_field('starts_at',16); $date=DateTime::createFromFormat('!Y-m-d\TH:i',$start);
        if (!$date || $date->format('Y-m-d\TH:i')!==$start) throw new RuntimeException('La fecha u hora de la cita no es válida.');
        date_value($date->format('Y-m-d'));
        $notes=text_field('notes',2000,false); $status=text_field('status',20);
        if (!in_array($status,['pendiente','confirmada'],true)) throw new RuntimeException('Estado inválido.');
        db()->beginTransaction();
        $old=$id?one('SELECT * FROM appointments WHERE id=? FOR UPDATE',[$id]):null;
        if ($id && (!$old || !in_array($old['status'],['pendiente','confirmada'],true))) throw new RuntimeException('Esta cita ya no puede editarse.');
        // Un bloqueo por profesional serializa las reservas concurrentes.
        $professional=one('SELECT * FROM staff WHERE id=? AND active=1 FOR UPDATE',[$staff]);
        if (!$professional) throw new RuntimeException('Selecciona un profesional activo.');
        $svc=active_record('services',$service);
        $duration=($old && (int)$old['service_id']===$service)?(int)((strtotime($old['ends_at'])-strtotime($old['starts_at']))/60):(int)$svc['duration'];
        $price=($old && (int)$old['service_id']===$service)?$old['price']:$svc['price'];
        $end=(clone $date)->modify('+'.$duration.' minutes')->format('Y-m-d H:i:s'); $start=$date->format('Y-m-d H:i:s');
        $overlap=one("SELECT id FROM appointments WHERE staff_id=? AND id<>? AND status IN ('pendiente','confirmada') AND starts_at<? AND ends_at>? LIMIT 1 FOR UPDATE",[$staff,$id,$end,$start]);
        if ($overlap) throw new RuntimeException('Ese profesional ya tiene una cita en ese horario. Selecciona otra hora.');
        require_once __DIR__.'/appointment-client.php';
        $client=appointment_client($clientName,(int)($old['client_id'] ?? 0));
        if ($old) run('UPDATE appointments SET client_id=?,service_id=?,staff_id=?,starts_at=?,ends_at=?,price=?,status=?,notes=? WHERE id=?',[$client,$service,$staff,$start,$end,$price,$status,$notes,$id]);
        else run('INSERT INTO appointments (client_id,service_id,staff_id,starts_at,ends_at,price,status,notes) VALUES (?,?,?,?,?,?,?,?)',[$client,$service,$staff,$start,$end,$price,$status,$notes]);
        db()->commit(); flash('Cita guardada.'); go('index.php?page=appointments');
    }
    if ($action==='cancel_appointment') {
        $id=int_field('id',1);
        run("UPDATE appointments SET status='cancelada' WHERE id=? AND status IN ('pendiente','confirmada')",[$id]);
        flash('Solicitud de cancelación procesada. Las citas cobradas no se pueden cancelar.'); go('index.php?page=appointments');
    }
    if ($action==='pay') {
        $id=int_field('id',1); $method=text_field('method',20);
        if (!in_array($method,['efectivo','tarjeta','transferencia'],true)) throw new RuntimeException('Selecciona un método de pago válido.');
        db()->beginTransaction(); $a=one('SELECT * FROM appointments WHERE id=? FOR UPDATE',[$id]);
        if (!$a || !in_array($a['status'],['pendiente','confirmada'],true)) throw new RuntimeException('La cita está cancelada o ya fue cobrada.');
        run('INSERT INTO payments (appointment_id,amount,method,paid_at,user_id) VALUES (?,?,?,?,?)',[$id,$a['price'],$method,now(),$_SESSION['user']['id']]);
        run("UPDATE appointments SET status='completada' WHERE id=?",[$id]); db()->commit();
        flash('Cobro registrado por '.money($a['price']).'.'); go('index.php?page=payments');
    }
    if ($action==='stock') {
        require_admin(); $id=int_field('id',1); $qty=int_field('quantity',-1000000,1000000); $reason=text_field('reason',190);
        if ($qty===0) throw new RuntimeException('El movimiento debe ser distinto de cero.');
        db()->beginTransaction(); $p=one('SELECT * FROM products WHERE id=? AND active=1 FOR UPDATE',[$id]);
        if (!$p || (int)$p['stock']+$qty<0 || (int)$p['stock']+$qty>1000000) throw new RuntimeException('El movimiento deja existencias fuera del rango permitido (0 a 1,000,000).');
        run('UPDATE products SET stock=stock+? WHERE id=?',[$qty,$id]);
        run('INSERT INTO stock_movements (product_id,quantity,reason,created_at,user_id) VALUES (?,?,?,?,?)',[$id,$qty,$reason,now(),$_SESSION['user']['id']]);
        db()->commit(); flash('Existencias actualizadas.'); go('index.php?page=products');
    }
    if ($action==='expense') {
        require_admin();
        run('INSERT INTO expenses (description,category,amount,spent_on,user_id) VALUES (?,?,?,?,?)',[text_field('description',190),text_field('category',80),number_field('amount',0.01),date_value(text_field('spent_on',10)),$_SESSION['user']['id']]);
        flash('Gasto registrado.'); go('index.php?page=expenses');
    }
    if ($action==='settings') {
        require_admin(); $name=text_field('business_name',120); $phone=text_field('phone',30,false); $address=text_field('address',300,false);
        db()->beginTransaction();
        foreach (['business_name'=>$name,'phone'=>$phone,'address'=>$address] as $k=>$v) run('INSERT INTO settings (name,value) VALUES (?,?) ON DUPLICATE KEY UPDATE value=VALUES(value)',[$k,$v]);
        db()->commit(); flash('Datos del estudio actualizados.'); go('index.php?page=settings');
    }
    if ($action==='password') {
        $current=(string)($_POST['current_password'] ?? ''); $password=(string)($_POST['password'] ?? '');
        $u=one('SELECT * FROM users WHERE id=?',[$_SESSION['user']['id']]);
        if (!password_verify($current,$u['password'])) throw new RuntimeException('La contraseña actual no coincide.');
        if (strlen($password)<10 || strlen($password)>72) throw new RuntimeException('Usa una contraseña de 10 a 72 caracteres.');
        if ($password!==($_POST['password_confirm'] ?? '')) throw new RuntimeException('Las nuevas contraseñas no coinciden.');
        run('UPDATE users SET password=? WHERE id=?',[password_hash($password,PASSWORD_DEFAULT),$u['id']]);
        session_regenerate_id(true); flash('Contraseña actualizada.'); go('index.php?page=account');
    }
    if ($action==='user') {
        require_admin(); $name=text_field('name',120); $email=email_field(); $password=(string)($_POST['password'] ?? ''); $role=text_field('role',20);
        if (!$email || strlen($password)<10 || strlen($password)>72 || !in_array($role,['admin','recepcion'],true)) throw new RuntimeException('Completa el correo y una contraseña de 10 a 72 caracteres.');
        run('INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)',[$name,$email,password_hash($password,PASSWORD_DEFAULT),$role]);
        flash('Cuenta creada.'); go('index.php?page=users');
    }
    if ($action==='disable_user') {
        require_admin(); $id=int_field('id',1);
        if ($id===(int)$_SESSION['user']['id']) throw new RuntimeException('No puedes desactivar tu propia cuenta.');
        run('UPDATE users SET active=0 WHERE id=?',[$id]); flash('Cuenta desactivada.'); go('index.php?page=users');
    }
    throw new RuntimeException('Operación desconocida.');
} catch (Throwable $ex) {
    if (db()->inTransaction()) db()->rollBack();
    if ($ex instanceof PDOException) { error_log((string)$ex); $message='No se guardó el registro. Revisa códigos o correos duplicados y vuelve a intentarlo.'; }
    else $message=$ex->getMessage();
    flash($message,'error');
    // Recuperar formularios sin volver a mostrar contraseñas.
    $oldInput=$_POST;
    foreach (['password','password_confirm','current_password','csrf'] as $secret) unset($oldInput[$secret]);
    $_SESSION['old_input']=$oldInput;
    if ($action==='save_entity') $return.='&form=1'.(!empty($_POST['id'])?'&edit='.(int)$_POST['id']:'');
    if ($action==='save_appointment') $return='index.php?page=appointments&form=1'.(!empty($_POST['id'])?'&edit='.(int)$_POST['id']:'');
    go($return);
}
