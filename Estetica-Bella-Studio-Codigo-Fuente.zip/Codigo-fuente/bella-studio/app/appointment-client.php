<?php
function appointment_client(string $name, int $currentId=0): int {
    if ($name === '' || mb_strlen($name)>120) throw new RuntimeException('Escribe el nombre del cliente (máximo 120 caracteres).');
    $matches=rows('SELECT id FROM clients WHERE name=? AND active=1',[$name]);
    if (count($matches)===1) return (int)$matches[0]['id'];
    if (count($matches)>1) {
        foreach ($matches as $match) if ((int)$match['id']===$currentId) return $currentId;
        throw new RuntimeException('Hay varios clientes con ese nombre. Diferencia sus nombres en Clientes antes de guardar la cita.');
    }
    run("INSERT INTO clients (name,phone,email,notes) VALUES (?,'','','')",[$name]);
    return (int)db()->lastInsertId();
}
