<?php
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    check_csrf();
    // Contador persistente por IP: no se reinicia al borrar cookies.
    $file=dirname(__DIR__).'/storage/login-'.hash('sha256',$_SERVER['REMOTE_ADDR'] ?? 'local').'.json';
    $f=fopen($file,'c+');
    if (!$f) { http_response_code(503); exit('La carpeta storage debe permitir escritura.'); }
    flock($f,LOCK_EX); $state=json_decode(stream_get_contents($f),true) ?: ['start'=>time(),'attempts'=>0];
    if (time()-(int)$state['start']>=900) $state=['start'=>time(),'attempts'=>0];
    if ((int)$state['attempts']>=8) $error='Demasiados intentos. Espera 15 minutos desde el primer intento y vuelve a ingresar.';
    else {
        $u=one('SELECT * FROM users WHERE email=? AND active=1',[mb_strtolower(trim((string)($_POST['email'] ?? '')))]);
        $valid=password_verify((string)($_POST['password'] ?? ''),$u['password'] ?? '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi');
        if ($u && $valid) {
            $state=['start'=>time(),'attempts'=>0];
            session_regenerate_id(true); $_SESSION['user']=['id'=>$u['id'],'name'=>$u['name'],'role'=>$u['role']]; $_SESSION['last_activity']=time();
        } else { $state['attempts']++; $error='El correo o la contraseña no coinciden.'; }
    }
    rewind($f); ftruncate($f,0); fwrite($f,json_encode($state)); fflush($f); flock($f,LOCK_UN); fclose($f);
    if (!$error) go('index.php');
}
?><!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Ingresar · Bella Studio</title><link rel="stylesheet" href="assets/style.css"></head><body class="auth-body"><main class="login-layout"><section class="login-story"><div class="eyebrow">BELLEZA QUE SE ORGANIZA</div><h1>Más tiempo<br>para hacer<br><em>sentir bien.</em></h1><p>Tu agenda, tus clientes y cada detalle de tu estudio, en un mismo lugar.</p><div class="story-flower">✧</div><div class="story-sign">Estética Bella Studio <span>BEAUTY & WELLNESS</span></div></section><section class="login-card"><div class="brand-mark">B<span>✧</span></div><h2>Bienvenida de nuevo</h2><p class="muted">Un nuevo día para crear algo bonito.</p>
<?php if ($error): ?><div class="notice error" role="alert"><?=e($error)?></div><?php endif ?>
<?php if (!empty($_SESSION['flash'])): ?><div class="notice"><?=e($_SESSION['flash'][0])?></div><?php unset($_SESSION['flash']); endif ?>
<form method="post"><?=csrf()?><label>Correo electrónico<input type="email" name="email" value="<?=e($_POST['email'] ?? '')?>" required autocomplete="username" maxlength="190"></label><label>Contraseña<input type="password" name="password" required autocomplete="current-password"></label><button class="btn" type="submit">Entrar a mi estudio <span>→</span></button></form><p class="login-foot">Acceso privado · Administración del estudio</p></section></main></body></html>
