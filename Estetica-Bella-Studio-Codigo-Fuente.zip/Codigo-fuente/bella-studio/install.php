<?php
require __DIR__.'/app/bootstrap.php';
if (is_file(__DIR__.'/config.php')) { http_response_code(403); exit('El sistema ya está configurado. Abre index.php.'); }
if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1','::1'],true)) { http_response_code(403); exit('Instala desde el navegador del equipo local: http://localhost/bella-studio/install.php'); }
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    check_csrf(); $pdo=null; $locked=false;
    try {
        if (!extension_loaded('pdo_mysql') || !extension_loaded('mbstring')) throw new RuntimeException('Activa pdo_mysql y mbstring en PHP y reinicia Apache.');
        if (!is_writable(__DIR__) || !is_writable(__DIR__.'/storage')) throw new RuntimeException('La carpeta del proyecto y storage deben permitir escritura.');
        $host=text_field('host',190); $port=int_field('port',1,65535); $database=text_field('database',60);
        if (!preg_match('/^[a-zA-Z0-9_]+$/D',$database) || !preg_match('/^[a-zA-Z0-9.\-:]+$/D',$host)) throw new RuntimeException('Usa un nombre de base sin espacios y un servidor válido.');
        $username=text_field('username',120); $dbpass=(string)($_POST['db_password'] ?? '');
        $name=text_field('name',120); $email=email_field(); $password=(string)($_POST['password'] ?? '');
        if (!$email || strlen($password)<10 || strlen($password)>72) throw new RuntimeException('Indica un correo válido y una contraseña administradora de 10 a 72 caracteres.');
        if ($password!==($_POST['password_confirm'] ?? '')) throw new RuntimeException('Las contraseñas administradoras no coinciden.');
        $pdo=new PDO('mysql:host='.$host.';port='.$port.';charset=utf8mb4',$username,$dbpass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_TIMEOUT=>5]);
        $lock=$pdo->prepare('SELECT GET_LOCK(?,10)'); $lock->execute(['bella_install_'.$database]);
        if ((int)$lock->fetchColumn()!==1) throw new RuntimeException('Hay otra instalación en curso. Intenta de nuevo.');
        $locked=true;
        if (is_file(__DIR__.'/config.php')) throw new RuntimeException('La instalación ya fue completada.');
        $pdo->exec('CREATE DATABASE IF NOT EXISTS `'.$database.'` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
        $pdo->exec('USE `'.$database.'`');
        // No tocar una base existente: solamente puede continuarse un esquema vacío de Bella.
        $tables=$pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
        $allowed=['settings','users','clients','services','staff','appointments','payments','products','stock_movements','expenses'];
        foreach ($tables as $table) {
            if (!in_array($table,$allowed,true) || (int)$pdo->query('SELECT COUNT(*) FROM `'.$table.'`')->fetchColumn()>0) throw new RuntimeException('La base ya contiene datos. Elige una base nueva y vacía; no se reemplazará información.');
        }
        $sql=file_get_contents(__DIR__.'/database/schema.sql');
        foreach (explode(';',$sql) as $statement) if (trim($statement)!=='') $pdo->exec($statement);
        $pdo->beginTransaction();
        $s=$pdo->prepare('INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)'); $s->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT),'admin']);
        $s=$pdo->prepare('INSERT INTO settings (name,value) VALUES (?,?)');
        foreach (['business_name'=>'Estética Bella Studio','phone'=>'','address'=>'','installed_at'=>now()] as $k=>$v) $s->execute([$k,$v]);
        $s=$pdo->prepare('INSERT INTO services (name,category,price,duration) VALUES (?,?,?,?)');
        foreach ([['Corte y peinado','Cabello',350,60],['Manicure clásico','Uñas',250,45],['Diseño de cejas','Mirada',180,30],['Limpieza facial','Facial',650,60]] as $row) $s->execute($row);
        // Escritura exclusiva: una instalación no puede sobrescribir configuración existente.
        $cfg=['host'=>$host,'port'=>$port,'database'=>$database,'username'=>$username,'password'=>$dbpass];
        $content="<?php\n// Generado por el instalador. Mantener privado.\nreturn ".var_export($cfg,true).";\n";
        $f=fopen(__DIR__.'/config.php','x');
        if (!$f) throw new RuntimeException('No fue posible crear config.php.');
        $written=fwrite($f,$content); fclose($f);
        if ($written!==strlen($content)) { unlink(__DIR__.'/config.php'); throw new RuntimeException('No hay espacio suficiente para guardar la configuración.'); }
        try { $pdo->commit(); } catch (Throwable $commitError) { unlink(__DIR__.'/config.php'); throw $commitError; }
        $pdo->prepare('SELECT RELEASE_LOCK(?)')->execute(['bella_install_'.$database]);
        flash('Instalación completada. Ingresa con la cuenta que acabas de crear.'); go('index.php');
    } catch (Throwable $ex) {
        if ($pdo && $pdo->inTransaction()) $pdo->rollBack();
        if ($locked) $pdo->prepare('SELECT RELEASE_LOCK(?)')->execute(['bella_install_'.$database]);
        error_log((string)$ex);
        $error=$ex instanceof PDOException?'No se pudo preparar la base de datos. Revisa que MySQL esté iniciado, el puerto, usuario, contraseña y permisos.':$ex->getMessage();
    }
}
?><!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Instalar · Bella Studio</title><link rel="stylesheet" href="assets/style.css"></head><body class="auth-body"><main class="install-card"><div class="brand-mark">B<span>✧</span></div><div class="eyebrow">BIENVENIDA A TU NUEVO ESPACIO</div><h1>Estética Bella Studio</h1><p class="muted">Configura tu estudio en unos minutos.</p>
<?php if ($error): ?><div class="notice error" role="alert"><?=e($error)?></div><?php endif ?>
<form method="post"><?=csrf()?><h2>01 · Conexión a MySQL</h2><p class="muted">En AppServ normalmente: 127.0.0.1, puerto 3306, usuario root y la contraseña MySQL que elegiste al instalar AppServ. En XAMPP suele estar vacía si no la cambiaste.</p><div class="form-grid">
<?php foreach (['host'=>['Servidor','127.0.0.1'],'port'=>['Puerto','3306'],'database'=>['Base de datos nueva','bella_studio'],'username'=>['Usuario MySQL','root']] as $k=>$f): ?><label><?=e($f[0])?><input name="<?=e($k)?>" value="<?=e($_POST[$k] ?? $f[1])?>" required></label><?php endforeach ?>
<label class="span-2">Contraseña MySQL<input type="password" name="db_password" autocomplete="off"></label></div>
<h2>02 · Tu cuenta administradora</h2><div class="form-grid"><label>Nombre<input name="name" value="<?=e($_POST['name'] ?? '')?>" required maxlength="120" autocomplete="name"></label><label>Correo<input type="email" name="email" value="<?=e($_POST['email'] ?? '')?>" maxlength="190" required autocomplete="email"></label><label>Contraseña<input type="password" name="password" minlength="10" maxlength="72" required autocomplete="new-password"></label><label>Repetir contraseña<input type="password" name="password_confirm" minlength="10" maxlength="72" required autocomplete="new-password"></label></div><p class="muted">Mínimo 10 caracteres. Se crearán cuatro servicios de ejemplo que puedes editar; tu agenda iniciará vacía.</p><button class="btn" type="submit">Crear mi estudio <span>→</span></button></form><footer>AppServ / XAMPP · PHP 7.3–8.x · MySQL / MariaDB · Sin dependencias externas</footer></main></body></html>
