# Estética Bella Studio

Sistema administrativo local en PHP y MySQL para AppServ y XAMPP. Diseño adaptable en rosa, blanco y dorado. Todo funciona sin Internet, Composer, Node ni servicios externos.

## Instalar en Windows con AppServ

1. Descomprime el ZIP. Copia la carpeta **bella-studio** dentro de `C:\AppServ\www`. Si instalaste AppServ en otra ubicación, usa su carpeta `www`.
2. Comprueba que los servicios **Apache** y **MySQL** de AppServ estén iniciados. Puedes comprobarlo abriendo `http://localhost/` y mediante la aplicación **Servicios** de Windows. No necesitas instalar XAMPP.
3. Abre **http://localhost/bella-studio/** en el navegador del mismo equipo. No abras los archivos PHP con doble clic.
4. Completa el instalador con los datos de tu AppServ:
   - Servidor: `127.0.0.1`
   - Puerto MySQL: `3306`
   - Base nueva: `bella_studio`
   - Usuario MySQL: `root`
   - Contraseña MySQL: **la que elegiste al instalar AppServ**. No es necesariamente vacía; es distinta de la contraseña de acceso a Bella Studio.
5. Crea tu cuenta administradora con un correo y una contraseña de 10 a 72 caracteres. **No hay una contraseña predefinida**.
6. El instalador crea la base, las tablas, cuatro servicios editables y `config.php`. Ingresa con la cuenta que creaste.

Si Apache usa otro puerto, por ejemplo 8080, abre `http://localhost:8080/bella-studio/`. El puerto de Apache es distinto del puerto MySQL solicitado en el formulario.

### Si utilizas XAMPP en otro equipo

El mismo sistema funciona copiando `bella-studio` a `C:\xampp\htdocs` e iniciando Apache y MySQL desde su panel. En XAMPP la contraseña MySQL suele estar vacía si no se ha cambiado. Usa siempre las credenciales del equipo donde instales.

El instalador acepta solicitudes únicamente desde localhost y se bloquea al existir `config.php`. No reemplaza una base con datos. Si tu usuario MySQL no puede crear bases, crea una **base vacía** desde phpMyAdmin, otorga permisos al usuario y utiliza ese nombre en el instalador. No debes importar el SQL antes: el instalador lo hace automáticamente. `database/schema.sql` incluye el esquema para consulta y mantenimiento.

## Primeros pasos

1. En **Mi estudio**, guarda nombre, teléfono y dirección del negocio.
2. En **Personal**, crea los profesionales. Las cuentas de acceso se crean aparte en **Usuarios**.
3. En **Servicios**, revisa los precios y duraciones de ejemplo, o agrega los tuyos.
4. En **Agenda**, escribe el nombre del cliente. Puedes usar las sugerencias de clientes registrados o escribir uno nuevo; se creará al guardar la cita. Puedes completar su teléfono y demás datos en **Clientes**. Si existen nombres idénticos, diferéncialos allí antes de crear una nueva cita.
5. Cuando recibas el pago, selecciona **Cobrar**, elige el método y confirma. La cita pasa a completada.
6. Registra compras y otros desembolsos en **Gastos**. Consulta **Reportes** por rango de fechas y exporta los cobros en CSV o imprime el reporte.

## Módulos y reglas

| Módulo | Funciones |
| --- | --- |
| Resumen | Citas e ingresos del día, clientes activos y alertas de inventario |
| Clientes | Crear, editar, buscar, archivar, reactivar y guardar preferencias |
| Servicios | Nombre, categoría, precio y duración de 5 a 720 minutos |
| Personal | Profesionales, especialidad y teléfono |
| Agenda | Crear y reprogramar citas, confirmar, cancelar, filtrar por día y estado |
| Cobros | Pago completo por cita, efectivo/tarjeta/transferencia, folio e historial |
| Inventario | Productos, SKU único, costo, mínimo, entradas y salidas con motivo y responsable |
| Gastos | Concepto, categoría, fecha, importe y responsable |
| Reportes | Ingresos, gastos, balance de caja, servicios y métodos de pago, CSV e impresión |
| Usuarios | Crear cuentas administradoras o de recepción, desactivar accesos |
| Mi estudio / Mi cuenta | Datos del negocio y cambio de contraseña propia |

- Una cita incluye **un servicio y un profesional**. Para varios servicios crea citas consecutivas. No se permiten citas pendientes o confirmadas que se superpongan para un mismo profesional. No se valida disponibilidad por cliente ni horario de apertura; puedes reservar cualquier hora.
- El precio y la duración se guardan al reservar. Si después cambias el catálogo y editas la misma cita con el mismo servicio, sus valores se conservan; seleccionar otro servicio adopta sus valores actuales. Los nombres se consultan desde los catálogos.
- El cobro es por el importe completo guardado de la cita. No hay anticipos, descuentos, propinas, reembolsos ni cobros parciales. Un pago no se puede registrar dos veces. Las citas cobradas no se editan ni cancelan.
- Los cobros y gastos son registros permanentes en esta versión; verifica los datos antes de confirmar. No se emiten CFDI ni se conectan terminales bancarias.
- Los productos son insumos de uso interno. El stock inicia en cero; usa **Mover stock**, con cantidad positiva para entrada y negativa para salida. Se registra quién hizo el movimiento y no se permite stock negativo. No hay venta de productos ni consumo automático por servicio.
- Archivar clientes, servicios, personal o productos conserva el historial. Desde **Ver archivados** puedes reactivarlos. Una cita pendiente con referencias archivadas requiere reactivar esos registros para editarla; puede cobrarse o cancelarse normalmente.
- **Recepción** gestiona clientes, citas y cobros y consulta catálogos e inventario. **Administración** también modifica servicios, personal e inventario y accede a gastos, reportes, usuarios y ajustes. Todos pueden cambiar su propia contraseña.
- Los usuarios desactivados pierden acceso al realizar su siguiente solicitud. No puedes desactivar tu propia cuenta. La desactivación es permanente desde la interfaz; crea otra cuenta con un correo distinto si se necesita un nuevo acceso.
- El balance es **ingresos cobrados menos gastos registrados**; no representa utilidad contable. Las compras de inventario se registran manualmente como gastos. No incluye impuestos, depreciación ni costos de insumos automáticos.
- Moneda: **MXN**. Zona horaria: **America/Mexico_City**. Los reportes usan la fecha del cobro y la del gasto, con límites inclusivos. Las tablas operativas muestran hasta 500 registros (movimientos: 100); los totales y exportaciones del periodo incluyen todos.

## Requisitos

- Apache 2.4 con acceso a `.htaccess` (`AllowOverride All`).
- PHP 7.3 o superior, incluidas las versiones 8.x. Extensiones `pdo_mysql`, `mbstring`, sesiones y funciones de contraseña. Se detectaron PHP 7.3.10 y estas extensiones en el AppServ de este equipo.
- MySQL 5.7+ o MariaDB 10.4+ con InnoDB y utf8mb4.
- Permiso de escritura en la carpeta del proyecto durante la instalación y en `storage` para los registros y el control de intentos de acceso.

Se recomienda una versión mantenida de PHP. El sistema está destinado a **localhost**. Para publicarlo en Internet se requiere preparar HTTPS, un usuario de base con permisos limitados, copias de seguridad y una revisión del despliegue.

## Archivos

```text
bella-studio/
  index.php              Acceso y administración
  install.php            Instalador inicial
  config.example.php     Ejemplo de conexión; no es necesario editarlo
  app/                   Lógica, seguridad y vistas
  assets/                Estilos y comportamiento de la interfaz
  database/schema.sql    Tablas y relaciones
  storage/               Registros privados y limitación de accesos
  LEEME.html             Guía breve para comenzar
  README.md              Este manual
```

No se incluyen credenciales, datos de clientes ni resultados de prueba en el paquete. `config.php` se genera en tu equipo y no debe compartirse. Las carpetas internas están protegidas por `.htaccess` para Apache. El servidor integrado de PHP no interpreta estas protecciones y no debe usarse como despliegue público.

## Copias de seguridad

Con MySQL iniciado, abre `http://localhost/phpmyadmin`, selecciona la base del estudio y usa **Exportar → Personalizado → SQL**, incluyendo estructura y datos de todas las tablas. Conserva el archivo en un lugar privado fuera de `htdocs`. Copia también `config.php` por separado, de forma segura.

Para recuperar, crea una base vacía e importa el respaldo desde phpMyAdmin. En una copia del proyecto coloca el `config.php` de respaldo y ajusta sus datos de conexión. **No ejecutes el instalador sobre un respaldo con datos.** Verifica el acceso y los reportes antes de volver a trabajar.

## Si algo no funciona

- **No abre localhost:** comprueba el servicio Apache de AppServ, revisa el puerto y conflictos con otros servidores.
- **Se descarga el PHP o aparece su código:** abre la dirección de localhost; no uses el archivo con doble clic.
- **Falla la conexión:** inicia MySQL y revisa sus credenciales y puerto. Después de instalar, están en `config.php`.
- **PHP 7.3 con MySQL 8 / error 2054:** este AppServ tiene PHP 7.3.10 y MySQL 8.0.17. Ese PHP puede no reconocer la autenticación `caching_sha2_password` si la cuenta MySQL la usa. En ese caso, un administrador debe crear una cuenta exclusiva compatible con `mysql_native_password` y permisos solamente sobre la base nueva de Bella Studio, o actualizar PHP a una versión compatible. El instalador no cambia usuarios ni contraseñas MySQL existentes. No se ha comprobado el método de autenticación de tu cuenta real; puede que ya sea compatible.
- **Base con datos:** el instalador protege bases existentes; selecciona un nombre nuevo o recupera el `config.php` original.
- **No se guarda config.php o el acceso falla:** revisa permisos de escritura del proyecto y `storage`. El diagnóstico privado está en `storage/php-errors.log`.
- **Demasiados intentos de acceso:** espera 15 minutos desde el primer intento. Se permiten ocho intentos por IP en esa ventana, incluso al borrar cookies.
- **Formulario vencido:** vuelve a cargar la página. El acceso vence después de dos horas sin actividad.
- **Olvidaste tu contraseña:** otra cuenta administradora puede crear una cuenta nueva con otro correo. Esta versión no envía enlaces de recuperación por correo. Mantén una segunda cuenta administradora de respaldo.
- **La cita no se guarda:** revisa que cliente, servicio y profesional estén activos y que no exista otra cita de ese profesional en ese intervalo.

Este proyecto se creó desde cero, sin usar `plantilla.zip`, que no estuvo disponible.
