<?php
// El instalador genera config.php. No publiques este archivo con credenciales reales.
return [
    'host' => '127.0.0.1', 'port' => 3306, 'database' => 'bella_studio',
    'username' => 'root', 'password' => '',
];
