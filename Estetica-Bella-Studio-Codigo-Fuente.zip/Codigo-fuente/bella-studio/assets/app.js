'use strict';
document.querySelectorAll('form[data-confirm]').forEach(form => {
  form.addEventListener('submit', event => {
    if (!window.confirm(form.dataset.confirm)) event.preventDefault();
  });
});
const toggle = document.querySelector('.menu-button');
if (toggle) toggle.addEventListener('click', () => {
  const opened = document.body.classList.toggle('menu-open');
  toggle.setAttribute('aria-expanded', String(opened));
});
document.querySelectorAll('[data-print]').forEach(button => button.addEventListener('click', () => window.print()));
